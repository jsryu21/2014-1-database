<?php
exec('/home/jsryu21/crawler.py');
echo "Crawling done!";
?>
<form method="post" action="index.html">
	<button type="submit">돌아가기</button>
</form>
